
"use strict";

let JointTorqueComparison = require('./JointTorqueComparison.js');

module.exports = {
  JointTorqueComparison: JointTorqueComparison,
};
