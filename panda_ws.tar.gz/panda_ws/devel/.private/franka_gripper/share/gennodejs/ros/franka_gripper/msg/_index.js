
"use strict";

let MoveActionResult = require('./MoveActionResult.js');
let MoveActionFeedback = require('./MoveActionFeedback.js');
let GraspAction = require('./GraspAction.js');
let GraspFeedback = require('./GraspFeedback.js');
let StopGoal = require('./StopGoal.js');
let HomingResult = require('./HomingResult.js');
let HomingGoal = require('./HomingGoal.js');
let HomingActionFeedback = require('./HomingActionFeedback.js');
let MoveResult = require('./MoveResult.js');
let HomingFeedback = require('./HomingFeedback.js');
let GraspActionFeedback = require('./GraspActionFeedback.js');
let GraspActionResult = require('./GraspActionResult.js');
let MoveAction = require('./MoveAction.js');
let GraspResult = require('./GraspResult.js');
let StopResult = require('./StopResult.js');
let StopFeedback = require('./StopFeedback.js');
let MoveGoal = require('./MoveGoal.js');
let GraspActionGoal = require('./GraspActionGoal.js');
let MoveFeedback = require('./MoveFeedback.js');
let HomingActionGoal = require('./HomingActionGoal.js');
let MoveActionGoal = require('./MoveActionGoal.js');
let StopActionFeedback = require('./StopActionFeedback.js');
let HomingAction = require('./HomingAction.js');
let HomingActionResult = require('./HomingActionResult.js');
let StopActionGoal = require('./StopActionGoal.js');
let GraspGoal = require('./GraspGoal.js');
let StopActionResult = require('./StopActionResult.js');
let StopAction = require('./StopAction.js');
let GraspEpsilon = require('./GraspEpsilon.js');

module.exports = {
  MoveActionResult: MoveActionResult,
  MoveActionFeedback: MoveActionFeedback,
  GraspAction: GraspAction,
  GraspFeedback: GraspFeedback,
  StopGoal: StopGoal,
  HomingResult: HomingResult,
  HomingGoal: HomingGoal,
  HomingActionFeedback: HomingActionFeedback,
  MoveResult: MoveResult,
  HomingFeedback: HomingFeedback,
  GraspActionFeedback: GraspActionFeedback,
  GraspActionResult: GraspActionResult,
  MoveAction: MoveAction,
  GraspResult: GraspResult,
  StopResult: StopResult,
  StopFeedback: StopFeedback,
  MoveGoal: MoveGoal,
  GraspActionGoal: GraspActionGoal,
  MoveFeedback: MoveFeedback,
  HomingActionGoal: HomingActionGoal,
  MoveActionGoal: MoveActionGoal,
  StopActionFeedback: StopActionFeedback,
  HomingAction: HomingAction,
  HomingActionResult: HomingActionResult,
  StopActionGoal: StopActionGoal,
  GraspGoal: GraspGoal,
  StopActionResult: StopActionResult,
  StopAction: StopAction,
  GraspEpsilon: GraspEpsilon,
};
