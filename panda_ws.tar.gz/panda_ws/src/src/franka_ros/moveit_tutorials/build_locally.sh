#!/bin/sh

rm -rf build
rosdoc_lite -o build .
