#include <ros/ros.h>

#include <moveit/move_group_interface/move_group_interface.h>
#include <moveit/planning_scene_interface/planning_scene_interface.h>

#include <moveit_msgs/DisplayRobotState.h>
#include <moveit_msgs/DisplayTrajectory.h>

#include <moveit_msgs/AttachedCollisionObject.h>
#include <moveit_msgs/CollisionObject.h>

#include <moveit_visual_tools/moveit_visual_tools.h>

#include <algorithm> // for std::max

// Seems too complicated to create those global variables within the function addCollisionObjects seems it needs to use pointers and I am lazy. However this way cannot use the adjective extern CONST double so those variables may be subject to redefinitions, which I would avoid since it only has to be defined once within addCollisionObjects but well...
double STYLET_RADIUS;
double STYLET_HEIGHT;
double STYLET_EE_X;
double STYLET_EE_Z;
double STYLET_EE_Y;
double OFFSET_BLACK_GOMUGOMU = 0.019; //width of the 2 pads between the fingers : 1.9cm

void addCollisionObjects(moveit::planning_interface::PlanningSceneInterface& planning_scene_interface, std::vector<moveit_msgs::CollisionObject>& collision_objects)
{
  const double DIST_ARM_TABLE = 0.2; // [m], shortest distance between the central vertical axis of the first robot link, and the nearest edge of the experiment table.
  const double SHIFT_ZBASE_ZPANDA = 0.075; // The central vertical axis of the designed base is shifted of -7.5cm from the central vertical axis of the robot in the x direction
  const double SHIFT_ORIGMONITOR_SURFACEDESK = 0.355; // maximal shift is 35.5cm for the FlexScanL887, brand EIZO
  const double TABLE_LENGTH = 0.8;
  // I assume quaternion.w=1 and then length <-> y, width <-> x, height <-> z
  const double TABLE_WIDTH = 0.7;
  const double TABLE_HEIGHT = 0.68;
  const double DESK_LENGTH = 1.20;
  const double DESK_WIDTH = 0.8;
  const double DESK_HEIGHT = 0.68;
  const double BASE_LENGTH = 0.46;
  const double BASE_WIDTH = 0.3;
  const double BASE_HEIGHT = 0.712;
  const double TABLET_LENGTH = 0.57;
  const double TABLET_WIDTH  = 0.345;
  const double TABLET_HEIGHT = 0.04;
  const double STANDS_LENGTH = 0.04;
  const double STANDS_WIDTH = STANDS_LENGTH;
  const double STANDS_HEIGHT = 0.08;
  STYLET_RADIUS = 0.0095;
  STYLET_HEIGHT = 0.114;
  const double MONITOR_FOOT_LENGTH = 0.075;
  const double MONITOR_FOOT_WIDTH = 0.075;
  const double MONITOR_FOOT_HEIGHT = 0.39;
  const double MONITOR_LENGTH = 0.445;
  const double MONITOR_WIDTH = 0.1;
  const double MONITOR_HEIGHT = 0.35;
  //About their placement, please see below
  // Creating Environment
  // ^^^^^^^^^^^^^^^^^^^^
  // Create vector to hold 9 collision objects.
  // - a biiig box including experiment table and workstation desk and panda base
  // - the monitor
  // - its foot
  // - the cylinder-shape boundingbox of the haptic stylet
  // - the tablet
  // - the stand1 for staying in the standby pose
  // - the stand2
  collision_objects.resize(9);
  // First add the base
  collision_objects[0].id = "base";
  collision_objects[0].header.frame_id = "panda_link0";
  /* Define the primitive and its dimensions. */
  collision_objects[0].primitives.resize(1);
  collision_objects[0].primitives[0].type = collision_objects[0].primitives[0].BOX;
  collision_objects[0].primitives[0].dimensions.resize(3);
  collision_objects[0].primitives[0].dimensions[0] = BASE_WIDTH;
  collision_objects[0].primitives[0].dimensions[1] = BASE_LENGTH;
  collision_objects[0].primitives[0].dimensions[2] = BASE_HEIGHT;
  /* Define the pose of the base. */
  collision_objects[0].primitive_poses.resize(1);
  collision_objects[0].primitive_poses[0].position.x = - SHIFT_ZBASE_ZPANDA;
  collision_objects[0].primitive_poses[0].position.y = 0.;
  collision_objects[0].primitive_poses[0].position.z = -BASE_HEIGHT/2;
  collision_objects[0].operation = collision_objects[0].ADD;
  
  // Add the table
  collision_objects[1].id = "table";
  collision_objects[1].header.frame_id = "panda_link0";
  /* Define the primitive and its dimensions. */
  collision_objects[1].primitives.resize(1);
  collision_objects[1].primitives[0].type = collision_objects[1].primitives[0].BOX;
  collision_objects[1].primitives[0].dimensions.resize(3);
  collision_objects[1].primitives[0].dimensions[0] = TABLE_WIDTH;
  collision_objects[1].primitives[0].dimensions[1] = TABLE_LENGTH;
  collision_objects[1].primitives[0].dimensions[2] = TABLE_HEIGHT;
  /* Define the pose of the table. */
  collision_objects[1].primitive_poses.resize(1);
  collision_objects[1].primitive_poses[0].position.x = DIST_ARM_TABLE + TABLE_WIDTH/2;
  collision_objects[1].primitive_poses[0].position.y = 0.;
  collision_objects[1].primitive_poses[0].position.z = -TABLE_HEIGHT/2 - (BASE_HEIGHT-TABLE_HEIGHT);
  collision_objects[1].operation = collision_objects[1].ADD;
  
  // Define the object that we will be manipulating
  collision_objects[2].id = "stylet";
  collision_objects[2].header.frame_id = "panda_link0";
  /* Define the primitive and its dimensions. */
  collision_objects[2].primitives.resize(1);
  collision_objects[2].primitives[0].type = collision_objects[1].primitives[0].CYLINDER;
  collision_objects[2].primitives[0].dimensions.resize(2);
  collision_objects[2].primitives[0].dimensions[0] = STYLET_HEIGHT; //docs.ros.org/jade/api/shape_msgs/html/msg/SolidPrimitive.html
  collision_objects[2].primitives[0].dimensions[1] = STYLET_RADIUS;
  /* Define the pose of the object. */
  collision_objects[2].primitive_poses.resize(1);
  collision_objects[2].primitive_poses[0].position.x = DIST_ARM_TABLE+0.1;
  collision_objects[2].primitive_poses[0].position.y = 0.3;
  collision_objects[2].primitive_poses[0].position.z = collision_objects[1].primitive_poses[0].position.z + TABLE_HEIGHT/2 + STYLET_HEIGHT/2;
  collision_objects[2].operation = collision_objects[2].ADD;
  // Give that position to the other int main function
  STYLET_EE_X = collision_objects[2].primitive_poses[0].position.x;
  STYLET_EE_Y = collision_objects[2].primitive_poses[0].position.y;
  STYLET_EE_Z = collision_objects[1].primitive_poses[0].position.z + TABLE_HEIGHT/2; //altitude of the peak of the stylet, not its geometric center
  
  // Add the tablet
  collision_objects[3].id = "tablet";
  collision_objects[3].header.frame_id = "panda_link0";
  /* Define the primitive and its dimensions. */
  collision_objects[3].primitives.resize(1);
  collision_objects[3].primitives[0].type = collision_objects[1].primitives[0].BOX;
  collision_objects[3].primitives[0].dimensions.resize(3);
  collision_objects[3].primitives[0].dimensions[0] = TABLET_WIDTH;
  collision_objects[3].primitives[0].dimensions[1] = TABLET_LENGTH;
  collision_objects[3].primitives[0].dimensions[2] = TABLET_HEIGHT;
  /* Define the pose of the tablet. */
  collision_objects[3].primitive_poses.resize(1);
  collision_objects[3].primitive_poses[0].position.x = DIST_ARM_TABLE+TABLE_WIDTH/2;
  collision_objects[3].primitive_poses[0].position.y = 0.;
  collision_objects[3].primitive_poses[0].position.z = collision_objects[1].primitive_poses[0].position.z + TABLE_HEIGHT/2 + TABLET_HEIGHT/2;
  collision_objects[3].operation = collision_objects[3].ADD;
  
  // Add the stand1
  collision_objects[4].id = "stand1";
  collision_objects[4].header.frame_id = "panda_link0";
  /* Define the primitive and its dimensions. */
  collision_objects[4].primitives.resize(1);
  collision_objects[4].primitives[0].type = collision_objects[1].primitives[0].BOX;
  collision_objects[4].primitives[0].dimensions.resize(3);
  collision_objects[4].primitives[0].dimensions[0] = STANDS_WIDTH;
  collision_objects[4].primitives[0].dimensions[1] = STANDS_LENGTH;
  collision_objects[4].primitives[0].dimensions[2] = STANDS_HEIGHT;
  /* Define the pose of the stand1 */
  collision_objects[4].primitive_poses.resize(1);
  collision_objects[4].primitive_poses[0].position.x = DIST_ARM_TABLE + TABLE_WIDTH/2 - 0.0375;
  collision_objects[4].primitive_poses[0].position.y = -TABLET_LENGTH/2 - STANDS_LENGTH/2;
  collision_objects[4].primitive_poses[0].position.z = collision_objects[1].primitive_poses[0].position.z + TABLE_HEIGHT/2 + STANDS_HEIGHT/2;
  collision_objects[4].operation = collision_objects[4].ADD;
  
  // Add the stand2
  collision_objects[5].id = "stand2";
  collision_objects[5].header.frame_id = "panda_link0";
  /* Define the primitive and its dimensions. */
  collision_objects[5].primitives.resize(1);
  collision_objects[5].primitives[0].type = collision_objects[1].primitives[0].BOX;
  collision_objects[5].primitives[0].dimensions.resize(3);
  collision_objects[5].primitives[0].dimensions[0] = STANDS_WIDTH;
  collision_objects[5].primitives[0].dimensions[1] = STANDS_LENGTH;
  collision_objects[5].primitives[0].dimensions[2] = STANDS_HEIGHT;
  /* Define the pose of the stand2 */
  collision_objects[5].primitive_poses.resize(1);
  collision_objects[5].primitive_poses[0].position.x = DIST_ARM_TABLE + TABLE_WIDTH/2 + 0.0375;
  collision_objects[5].primitive_poses[0].position.y = TABLET_LENGTH/2 + STANDS_LENGTH/2;
  collision_objects[5].primitive_poses[0].position.z = collision_objects[1].primitive_poses[0].position.z + TABLE_HEIGHT/2 + STANDS_HEIGHT/2;
  collision_objects[5].operation = collision_objects[5].ADD;
  
  // Add the desk
  collision_objects[6].id = "desk";
  collision_objects[6].header.frame_id = "panda_link0";
  /* Define the primitive and its dimensions. */
  collision_objects[6].primitives.resize(1);
  collision_objects[6].primitives[0].type = collision_objects[1].primitives[0].BOX;
  collision_objects[6].primitives[0].dimensions.resize(3);
  collision_objects[6].primitives[0].dimensions[0] = DESK_WIDTH;
  collision_objects[6].primitives[0].dimensions[1] = DESK_LENGTH;
  collision_objects[6].primitives[0].dimensions[2] = DESK_HEIGHT;
  /* Define the pose of the desk */
  collision_objects[6].primitive_poses.resize(1);
  collision_objects[6].primitive_poses[0].position.x = - SHIFT_ZBASE_ZPANDA - BASE_WIDTH/2 - DESK_WIDTH/2;
  collision_objects[6].primitive_poses[0].position.y = 0.;
  collision_objects[6].primitive_poses[0].position.z = -DESK_HEIGHT/2 - (BASE_HEIGHT-DESK_HEIGHT);
  collision_objects[6].operation = collision_objects[6].ADD;
  
  // Add the monitor's foot
  collision_objects[7].id = "monitor_foot";
  collision_objects[7].header.frame_id = "panda_link0";
  /* Define the primitive and its dimensions. */
  collision_objects[7].primitives.resize(1);
  collision_objects[7].primitives[0].type = collision_objects[1].primitives[0].BOX;
  collision_objects[7].primitives[0].dimensions.resize(3);
  collision_objects[7].primitives[0].dimensions[0] = MONITOR_FOOT_WIDTH;
  collision_objects[7].primitives[0].dimensions[1] = MONITOR_FOOT_LENGTH;
  collision_objects[7].primitives[0].dimensions[2] = MONITOR_FOOT_HEIGHT;
  /* Define the pose of the monitor's foot */
  collision_objects[7].primitive_poses.resize(1);
  collision_objects[7].primitive_poses[0].position.x = - SHIFT_ZBASE_ZPANDA - BASE_WIDTH/2 - MONITOR_FOOT_WIDTH/2;
  collision_objects[7].primitive_poses[0].position.y = 0.;
  collision_objects[7].primitive_poses[0].position.z = collision_objects[6].primitive_poses[0].position.z + DESK_HEIGHT/2 + MONITOR_FOOT_HEIGHT/2;
  collision_objects[7].operation = collision_objects[7].ADD;

  // Add the monitor
  collision_objects[8].id = "monitor";
  collision_objects[8].header.frame_id = "panda_link0";
  /* Define the primitive and its dimensions. */
  collision_objects[8].primitives.resize(1);
  collision_objects[8].primitives[0].type = collision_objects[1].primitives[0].BOX;
  collision_objects[8].primitives[0].dimensions.resize(3);
  collision_objects[8].primitives[0].dimensions[0] = MONITOR_WIDTH;
  collision_objects[8].primitives[0].dimensions[1] = MONITOR_LENGTH;
  collision_objects[8].primitives[0].dimensions[2] = MONITOR_HEIGHT;
  /* Define the pose of the monitor */
  collision_objects[8].primitive_poses.resize(1);
  collision_objects[8].primitive_poses[0].position.x = - SHIFT_ZBASE_ZPANDA - BASE_WIDTH/2 - MONITOR_FOOT_WIDTH - MONITOR_WIDTH/2;
  collision_objects[8].primitive_poses[0].position.y = 0.;
  collision_objects[8].primitive_poses[0].position.z = collision_objects[6].primitive_poses[0].position.z + DESK_HEIGHT/2 + SHIFT_ORIGMONITOR_SURFACEDESK;
  collision_objects[8].operation = collision_objects[7].ADD;

  planning_scene_interface.applyCollisionObjects(collision_objects);
}

void openGripper(trajectory_msgs::JointTrajectory& posture, double OFFSET_BLACK_GOMUGOMU)
{
  double openSymmetric = 0.03; //[m] how much each finger is shifted from the center
  /* Add both finger joints of panda robot. */
  posture.joint_names.resize(2);
  posture.joint_names[0] = "panda_finger_joint1";
  posture.joint_names[1] = "panda_finger_joint2";

  /* Set them as open, wide enough for the object to fit. */
  posture.points.resize(1);
  posture.points[0].positions.resize(2);
  posture.points[0].positions[0] = OFFSET_BLACK_GOMUGOMU/2 + openSymmetric;
  posture.points[0].positions[1] = OFFSET_BLACK_GOMUGOMU/2 + openSymmetric;
  std::cout << "opening = " << 2*posture.points[0].positions[0] << "m" << "\n";
}

void closedGripper(trajectory_msgs::JointTrajectory& posture, double OFFSET_BLACK_GOMUGOMU)
{
  // WOULD BE BETTER TO SET APPLIED FORCE INSTEAD, CHECK LIBFRANKA C++ [TODO]

  double closeSymmetric = 0.025; //[m] how much each finger is shifted from the center

  /* Add both finger joints of panda robot. */
  posture.joint_names.resize(2);
  posture.joint_names[0] = "panda_finger_joint1";
  posture.joint_names[1] = "panda_finger_joint2";

  /* Set them as closed. */
  posture.points.resize(1);
  posture.points[0].positions.resize(2);
  posture.points[0].positions[0] = OFFSET_BLACK_GOMUGOMU/2 + closeSymmetric;
  //OFFSET_BLACK_GOMUGOMU/2 + 0.0095;
  posture.points[0].positions[1] = OFFSET_BLACK_GOMUGOMU/2 + closeSymmetric;
  //OFFSET_BLACK_GOMUGOMU/2 + 0.0095;
  std::cout << "closing = " << 2*posture.points[0].positions[0] << "m" << "\n";
}

void pick(moveit::planning_interface::MoveGroupInterface& move_group, double OFFSET_BLACK_GOMUGOMU)
{
  double howfar = 0.1; //[m] from the object we want to arrive already in the good orientation
  double howdeep = 0.047; //assuming we approach the object to its cutting edge, howdeep we wanna continue. This value is anyway controlled below by the maximum leading to pushing the object in the approach direction...

  // Create a vector of grasps to be attempted, currently only creating single grasp.
  // This is essentially useful when using a grasp generator to generate and test multiple grasps.
  std::vector<moveit_msgs::Grasp> grasps;
  grasps.resize(1);
  // Setting grasp pose
  // ++++++++++++++++++++++
  // This is the pose of panda_link8. |br|, following comment is due to the online tutorial
  // From panda_link8 to the palm of the eef the distance is 0.058, the cube starts 0.01 before 5.0 (half of the length
  // of the cube). |br|
  // Therefore, the position for panda_link8 = 5 - (length of cube/2 - distance b/w panda_link8 and palm of eef - some
  // extra padding)
  grasps[0].grasp_pose.header.frame_id = "panda_link0";
//  grasps[0].grasp_pose.pose.orientation = tf::createQuaternionMsgFromRollPitchYaw(-M_PI / 2, -M_PI / 4, -M_PI / 2);
  grasps[0].grasp_pose.pose.orientation.w = 0.0;
  grasps[0].grasp_pose.pose.orientation.x = 1.0;
  grasps[0].grasp_pose.pose.orientation.y = 0.0;
  grasps[0].grasp_pose.pose.orientation.z = 0.0;
  grasps[0].grasp_pose.pose.position.x = STYLET_EE_X;
  grasps[0].grasp_pose.pose.position.y = STYLET_EE_Y;
  grasps[0].grasp_pose.pose.position.z = STYLET_EE_Z + STYLET_HEIGHT + howfar; //Without the 0.1 the lowest plane of the metallic finger comes on the top of the stylet before even having began its pre_grasp_approach
  std::cout << "x_goal = " << grasps[0].grasp_pose.pose.position.x << "m" << "\n";
  std::cout << "y_goal = " << grasps[0].grasp_pose.pose.position.y << "m" << "\n";
  std::cout << "z_goal = " << grasps[0].grasp_pose.pose.position.z << "m" << "\n";

  // Setting posture of eef before grasp
  // +++++++++++++++++++++++++++++++++++
  openGripper(grasps[0].pre_grasp_posture,OFFSET_BLACK_GOMUGOMU);

  // Setting pre-grasp approach
  // ++++++++++++++++++++++++++
  /* Defined with respect to frame_id */
  grasps[0].pre_grasp_approach.direction.header.frame_id = "panda_link0";
  /* Direction is set as negative z axis */
  grasps[0].pre_grasp_approach.direction.vector.z = -1.0;
//  grasps[0].pre_grasp_approach.min_distance = 0.095;
  grasps[0].pre_grasp_approach.desired_distance = howfar + std::min(howdeep,0.047); //4.7cm is the distance between the "hand palm" and the lowest plane of the fingers

  // Setting posture of eef during grasp
  // +++++++++++++++++++++++++++++++++++
  closedGripper(grasps[0].grasp_posture,OFFSET_BLACK_GOMUGOMU);

  // Setting post-grasp retreat
  // ++++++++++++++++++++++++++
  /* Defined with respect to frame_id */
  grasps[0].post_grasp_retreat.direction.header.frame_id = "panda_link0";
  /* Direction is set as positive z axis */
  grasps[0].post_grasp_retreat.direction.vector.z = 1.0;
//  grasps[0].post_grasp_retreat.min_distance = 0.1;
  grasps[0].post_grasp_retreat.desired_distance = howfar + std::min(howdeep,0.047);

  // Set support surface as table1.
  move_group.setSupportSurfaceName("table");
  // Call pick to pick up the object using the grasps given
  move_group.pick("stylet", grasps);
}

int main(int argc, char** argv, double OFFSET_BLACK_GOMUGOMU)
{
  ros::init(argc, argv, "move_group_interface_tutorial");
  ros::NodeHandle node_handle;
  ros::AsyncSpinner spinner(1);
  spinner.start();
  // MoveIt! operates on sets of joints called "planning groups" and stores them in an object called
  // the `JointModelGroup`. Throughout MoveIt! the terms "planning group" and "joint model group"
  // are used interchangably.
  static const std::string PLANNING_GROUP = "panda_arm";
  // The :move_group_interface:`MoveGroup` class can be easily
  // setup using just the name of the planning group you would like to control and plan for.
  moveit::planning_interface::MoveGroupInterface move_group(PLANNING_GROUP);
  //ROS_INFO("Reference frame %s", move_group.getEndEffectorLink().c_str());
  //move_group.setPlanningTime(45.0); //THIS LINE FUCKS UP EVERYTHING

  // We will use the :planning_scene_interface:`PlanningSceneInterface`
  // class to add and remove collision objects in our "virtual world" scene
  moveit::planning_interface::PlanningSceneInterface planning_scene_interface;
  std::vector<moveit_msgs::CollisionObject> collision_objects;
  addCollisionObjects(planning_scene_interface, collision_objects);
  // Wait a bit for ROS things to initialize
  ros::WallDuration(1.0).sleep();

  // Raw pointers are frequently used to refer to the planning group for improved performance.
  const robot_state::JointModelGroup* joint_model_group =
      move_group.getCurrentState()->getJointModelGroup(PLANNING_GROUP);

  // Visualization
  // ^^^^^^^^^^^^^
  //
  // The package MoveItVisualTools provides many capabilties for visualizing objects, robots,
  // and trajectories in RViz as well as debugging tools such as step-by-step introspection of a script
  namespace rvt = rviz_visual_tools;
  moveit_visual_tools::MoveItVisualTools visual_tools("panda_link0");
  visual_tools.deleteAllMarkers();

  // Remote control is an introspection tool that allows users to step through a high level script
  // via buttons and keyboard shortcuts in RViz
  visual_tools.loadRemoteControl();

  // RViz provides many types of markers, in this demo we will use text, cylinders, and spheres
  Eigen::Affine3d text_pose = Eigen::Affine3d::Identity();
  text_pose.translation().z() = 1.;
  visual_tools.publishText(text_pose, "MoveGroupInterface Demo", rvt::WHITE, rvt::XLARGE);

  // Batch publishing is used to reduce the number of messages being sent to RViz for large visualizations
  visual_tools.trigger();

  // Getting Basic Information
  // ^^^^^^^^^^^^^^^^^^^^^^^^^
  //
  // We can print the name of the reference frame for this robot.
  ROS_INFO_NAMED("tutorial", "Reference frame: %s", move_group.getPlanningFrame().c_str());

  // We can also print the name of the end-effector link for this group.
  ROS_INFO_NAMED("tutorial", "End effector link: %s", move_group.getEndEffectorLink().c_str());

/////////////////////////////////////////////////////////////////
//  openGripper(OFFSET_BLACK_GOMUGOMU); //wanna debug

  // Acquisition of the initial config
  // ^^^^^^^^^^^^^^^^^^^^^^^^^
  visual_tools.prompt("Press 'next' in the RvizVisualToolsGui window to acquire the immuable config");

  // To start, we'll create an pointer that references the current robot's state.
  // RobotState is the object that contains all the current position/velocity/acceleration data.
  moveit::core::RobotStatePtr current_state = move_group.getCurrentState();

  // Next get the current set of joint values for the group.
  std::vector<double> joint_group_positions;
  current_state->copyJointGroupPositions(joint_model_group, joint_group_positions);

  // Start the demo
  // ^^^^^^^^^^^^^^^^^^^^^^^^^
  visual_tools.prompt("Immuable joint positions acquired. Press 'next' in the RvizVisualToolsGui window to start the demo");

//  // Planning to a Pose goal
//  // ^^^^^^^^^^^^^^^^^^^^^^^
//  // We can plan a motion for this group to a desired pose for the
//  // end-effector.
//  geometry_msgs::Pose target_pose1;
//  target_pose1.orientation.x = 1.0;
////  target_pose1.position.x = 0.3;
////  target_pose1.position.y = 0.7;
////  target_pose1.position.z = 0.3;
//  target_pose1.position.x = STYLET_EE_X;
//  target_pose1.position.y = STYLET_EE_Y;
//  target_pose1.position.z = STYLET_EE_Z + STYLET_HEIGHT + 0.2;
//  move_group.setPoseTarget(target_pose1);

  pick(move_group, OFFSET_BLACK_GOMUGOMU);
  // Wait a bit for ROS things to initialize
  ros::WallDuration(1.0).sleep();

  // Come back to the verry beginning position
  // ^^^^^^^^^^^^^^^^^^^^^^^^^
  visual_tools.prompt("Experiment done. Press 'next' in the RvizVisualToolsGui window to come back to the earliest configuration");

  // Plan to the initial joint space goal and visualize the plan
  move_group.setJointValueTarget(joint_group_positions);
  // Now, we call the planner to compute the plan and visualize it.
  // Note that we are just planning, not asking move_group
  // to actually move the robot.
  moveit::planning_interface::MoveGroupInterface::Plan my_plan;

  bool success = (move_group.plan(my_plan) == moveit::planning_interface::MoveItErrorCode::SUCCESS);
  ROS_INFO_NAMED("tutorial", "Visualizing plan 1 (pose goal) %s", success ? "" : "FAILED");

  // Visualizing plans
  // ^^^^^^^^^^^^^^^^^
  // We can also visualize the plan as a line with markers in RViz.
  ROS_INFO_NAMED("tutorial", "Visualizing plan 1 as trajectory line");
  visual_tools.publishTrajectoryLine(my_plan.trajectory_, joint_model_group);
  visual_tools.trigger();
  visual_tools.prompt("Press 'next' in the RvizVisualToolsGui window to continue the demo");

  /* Uncomment below line when working with a real robot */
  move_group.move();

  // Now let's remove the scene from the world so that if we want to save some tweaks we did to the RViz interface, next time RViz is called for another purpose than thise scene avoiding, scene won't be displayed
//  ROS_INFO_NAMED("tutorial", "Scene removed.");
//  std::vector<std::string> object_ids;
//  object_ids.push_back(collision_objects.id);
//  planning_scene_interface.removeCollisionObjects(object_ids);

  // END_TUTORIAL
  ros::shutdown();
  return 0;
}
